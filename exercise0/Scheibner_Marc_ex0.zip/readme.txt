Completed Tasks:
- 0.1
- 0.2
- Bonus Task 0.3.1

Note to Tutor: It would be nice to know why the surface shader doesn't use the color vertex attribute 
		specified in variable "cgv::render::attribute_array_binding vertex_array_fractal" :)